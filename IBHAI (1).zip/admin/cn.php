<?php
$conexion = mysqli_connect("localhost", "u646610080_dentista","Dentistaibai1","u646610080_dentista");
//$server = "localhost";
//$user = "u646610080_dentista";
//$password = "Dentistaibai1";
 //$db_name = "u646610080_dentista";
mysqli_set_charset($conexion, "utf8");