<footer id="footer">
    <div class="footer-top">
        <div class="container">
            <div class="row">

                <div class="col-lg-6 col-md-6 footer-contact">
                    <h4 class="border-bottom border-2 border-primary mb-4 text-center">Durango Durango Mexico</h4>
                    <p>
                        <strong>Dirección:</strong>
                       Inserte direccion
                        <br><br>
                        <strong>Telefono: </strong> 618 137 4000<br>
                        <strong>Horario: </strong> Lunes a Viernes 8:00 - 16:00<br>.
                    </p>
                </div>
                <div class="col-lg-2"></div>
                <div class="col-lg-4 col-md-6 footer-links">
                    <h4 class="border-bottom border-2 border-primary mb-4 text-center">Números</h4>
                    <p>Cras fermentum odio eu feugiat lide par naso tierra videa magna derita valies</p>
                    <div class="mt-3">
                        <ul>
                            <!-- <li> Emergencias: <strong> 911</strong></li>
                            <li> Protección Civil: <strong> 6181379598</strong></li>
                            <li> Cruz Roja: <strong> 6188173444</strong></li> -->
                        </ul>
                    </div>
                </div>
                <div class="col-md-12 row d-flex justify-content-center">
                    <img class="img-fluid w-25" src="./assets/img/logo2.png" alt="logo">
                </div>
            </div>
        </div>
    </div>

    <div class="container py-4 border-top border-2 border-primary">
        <div class="text-center">
            &copy; Copyright <strong><span>IBHAI</span></strong>. Derechos reservados
            <?php echo date("Y") ?>
        </div>
    </div>
</footer>