<header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

        <div><a href="index.php"><img src="assets/img/logo2.png" width="150" alt="logo"></a></div>

        <nav id="navbar" class="navbar">
            <ul>
                <li><a class="btn btm-primary " href="index.php">Inicio</a></li>
               
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav>
    </div>
</header>