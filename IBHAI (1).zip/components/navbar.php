<header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

        <div><a href="index.php"><img src="assets/img/logo2.png" width="150" alt="logo"></a></div>

        <nav id="navbar" class="navbar">
            <ul>
                <li><a class="btn btm-primary " href="#hero">Inicio</a></li>
                <li><a class="btn btm-primary " href="#about">Nosotros</a></li>
                <li><a class="btn btm-primary " href="#services">Servicios</a></li>
                <li><a class="btn btm-primary " href="#doctors">Doctores</a></li>
                <li><a class="btn btm-primary " href="#galeria">Galeria</a></li>
                <li><a class="btn btm-primary " href="#contact">Contacto</a></li>
               <!--  <li><a class="btn btm-primary " href="./registro.php">Incidentes</a></li> -->
                <li><a class="btn btm-primary " href="./login.php">Acceder</a></li>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav>
    </div>
</header>